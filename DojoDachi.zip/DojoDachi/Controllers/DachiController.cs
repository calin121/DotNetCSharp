using System;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace DojoDachi.Controllers {
    public class DachiController : Controller {

        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            Dachi dachi = new Dachi();
            HttpContext.Session.SetObjectAsJson("dachi", dachi);
            ViewBag.dachi = dachi;
            return View("Index");
        }

        [HttpGet]
        [Route("feed")]
        public IActionResult Feed()
        {
            Dachi dachi = HttpContext.Session.GetObjectFromJson<Dachi>("dachi");
            dachi.Feed();
            HttpContext.Session.SetObjectAsJson("dachi", dachi);
            ViewBag.dachi = dachi;
            return Json(dachi);
        }

        [HttpGet]
        [Route("play")]
        public IActionResult Play()
        {  
            Dachi dachi = HttpContext.Session.GetObjectFromJson<Dachi>("dachi");
            dachi.Play();
            HttpContext.Session.SetObjectAsJson("dachi", dachi);
            ViewBag.dachi = dachi;
            return Json(dachi);
        }

        [HttpGet]
        [Route("work")]
        public IActionResult Work()
        {
            Dachi dachi = HttpContext.Session.GetObjectFromJson<Dachi>("dachi");
            dachi.Work();
            HttpContext.Session.SetObjectAsJson("dachi", dachi);
            ViewBag.dachi = dachi;
            return Json(dachi);
        }

        [HttpGet]
        [Route("sleep")]
        public IActionResult Sleep()
        {   
            Dachi dachi = HttpContext.Session.GetObjectFromJson<Dachi>("dachi");
            dachi.Sleep();
            HttpContext.Session.SetObjectAsJson("dachi", dachi);
            ViewBag.dachi = dachi;
            return Json(dachi);
        }

        [HttpGet]
        [Route("restart")]
        public IActionResult Restart()
        {
            // HttpContext.Session.Clear();
            Dachi dachi = new Dachi();
            HttpContext.Session.SetObjectAsJson("dachi", dachi);
            ViewBag.dachi = dachi;

            return Json(dachi); 
        }
    }
}
