using System;

namespace DojoDachi {
    
    public class Dachi {
        public int fullness {get; set;}
        public int happiness {get; set;}
        public int energy {get; set;}
        public int meals {get; set;}
        public string message {get; set;}
        public string reset {get; set;}
        public string playing {get; set;}
        Random rand = new Random();

        public Dachi()
        {
            fullness = 20;
            happiness = 20;
            meals = 3;
            energy = 50;
            message = "A new Dojodachi is born!";
            playing = "";
            reset = "display:none";
        }

        public void Feed()
        {
            int chance = rand.Next(1,5);
            if (meals < 1) {
                message = "You have no meals to fed your Dojodachi!";
            }
            else if (chance == 1) {
                meals -= 1;
                message = "You Dojomachi did not like what you fed it!";
            }
            else {
                meals -= 1;
                int gain = rand.Next(5, 11);
                fullness += gain;
                if (energy > 99 && fullness > 99 && happiness > 99) {
                    playing = "display:none";
                    reset = "";
                    message = "You have won!! Do you want to play again?";
                }
                else {
                    message = "You used on Meal and your Dojomachi gained " + gain + " fullness!";
                }
            }
        }
        public void Play()
        {   
            if (energy < 1) {
                message = "You have no energy left, you will need to sleep to give you Dojodachi more energy!";
            }
            else {
                energy -= 5;
                int chance = rand.Next(1,5);
                if (chance == 1) {
                    message = "You used 5 energy but received nothing in return because your Dojomachi did not like how you played with it!";
                }
                else {
                    int gain = rand.Next(5, 11);
                    happiness += gain;
                    if (energy > 99 && fullness > 99 && happiness > 99) {
                        playing = "display:none";
                        reset = "";
                        message = "You have won!! Do you want to play again?";
                    }
                    else {
                        message = "You used 5 energy and gained " +gain+ " in happiness!";
                    }
                }
            }
        }
        public void Work()
        {
            if (energy < 1) {
                message = "You have no energy left, you will need to sleep to give you Dojodachi more energy!";
            }
            else {
                energy -= 5;
                int gain = rand.Next(5, 11);
                meals += gain;
                message = "You used 5 energy and gained " +gain+ " to your meals!";
            }
        }
        public void Sleep()
        {
            fullness -= 5;
            happiness -= 5;
            if (fullness < 1 || happiness <1) {
                playing = "display:none";
                reset = "";
                message = "Your Dojodachi has passed away!";
            }
            
            else {
                energy += 15;
                if (energy > 99 && fullness > 99 && happiness > 99) {
                    playing = "display:none";
                    reset = "";
                    message = "You have won!! Do you want to play again?";
                }
                else {
                    message = "Your Dojodachi has gained 15 in energy, and used 5 in happiness and 5 in fullness";
                }
            }
        }
        // public void Reset()
        // {

        // }
    }
}