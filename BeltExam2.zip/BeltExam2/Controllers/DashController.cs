using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BeltExam.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BeltExam.Controllers
{

    public class DashController : Controller
    {
        private readonly DbConnector _dbConnector;

        public DashController(DbConnector connect)
        {
            _dbConnector = connect;
        }
        // GET: /Home/
        [HttpGet]
        [Route("dash")]
        public IActionResult Dash()
        {
            if(HttpContext.Session.GetInt32("id") != null){

                int? checkid = HttpContext.Session.GetInt32("id");
                int id = (int)checkid;
                string userQuery = $"SELECT * FROM users WHERE id = '{id}'";
                Dictionary<string, object> user = _dbConnector.Query(userQuery).SingleOrDefault();
                ViewBag.user = user;

                string ideasQuery = "SELECT alias, ideas.user_id AS user_id, idea, ideas.id AS idea_id, COUNT(likes.idea_id) AS likes FROM ideas JOIN users ON ideas.user_id = users.id Left JOIN likes ON ideas.id = likes.idea_id GROUP BY likes.idea_id ORDER BY likes DESC;";
                List<Dictionary<string, object>> ideas = _dbConnector.Query(ideasQuery).ToList();
                ViewBag.ideas = ideas;
                ViewBag.id = id;
                
                return View("Dash");
            }
            return RedirectToAction("index", "Users");
        }
        [HttpPost]
        [Route("add")]
        public IActionResult AddIdea(string idea)
        {
            if(HttpContext.Session.GetInt32("id") != null){
                
                int? checkid = HttpContext.Session.GetInt32("id");
                int id = (int)checkid;
                string newIdea = $"INSERT INTO ideas (idea, created_at, updated_at, user_id) VALUES ('{idea}', NOW(), NOW(), '{id}');";
                Dictionary<string, object> user = _dbConnector.Query(newIdea).SingleOrDefault();
                
                return RedirectToAction("dash");
            }
            return RedirectToAction("index", "Users");
        }
        [HttpGet]
        [Route("like/{idea_id}")]
        public IActionResult Like(int idea_id)
        {
            if(HttpContext.Session.GetInt32("id") != null){
                
                int? checkid = HttpContext.Session.GetInt32("id");
                int id = (int)checkid;
                string queryLikes = "SELECT * FROM likes;";
                List<Dictionary<string, object>> allLikes = _dbConnector.Query(queryLikes).ToList();
                // foreach(var like in allLikes) {
                    // if (like["id"] == idea_id && like["user_id"] == id) {
                    //     return RedirectToAction("dash");
                    // }
                    // else {
                        string newIdea = $"INSERT INTO likes (idea_id, created_at, updated_at, user_id) VALUES ('{idea_id}', NOW(), NOW(), '{id}');";
                        Dictionary<string, object> user = _dbConnector.Query(newIdea).SingleOrDefault();
                
                        return RedirectToAction("dash");
                    // }
                // }
            }
            return RedirectToAction("index", "Users");
        }
        [HttpGet]
        [Route("idea/{id}")]
        public IActionResult Idea(int id)
        {
            if(HttpContext.Session.GetInt32("id") != null){
                
                string ideaQuery = $"SELECT alias, idea FROM ideas JOIN users ON ideas.user_id = users.id WHERE ideas.id = '{id}';";
                Dictionary<string, object> idea = _dbConnector.Query(ideaQuery).SingleOrDefault();
                ViewBag.idea = idea;

                string likesQuery = $"SELECT alias, name, users.id AS id FROM users JOIN likes ON users.id = likes.user_id WHERE likes.idea_id = '{id}';";
                List<Dictionary<string, object>> likes = _dbConnector.Query(likesQuery).ToList();
                ViewBag.likes = likes;
                
                return View("Idea");
            }
            return RedirectToAction("index", "Users");
        }
        [HttpPost]
        [Route("remove/{id}")]
        public IActionResult Remove(int id)
        {
            if(HttpContext.Session.GetInt32("id") != null){
                
                string removeIdea = $"DELETE FROM likes WHERE likes.idea_id ='{id}'; DELETE FROM ideas WHERE id = '{id}';";
                _dbConnector.Execute(removeIdea);
                return RedirectToAction("dash");
            }
            return RedirectToAction("index", "Users");
        }
        [HttpGet]
        [Route("profile/{id}")]
        public IActionResult Profile(int id)
        {
            if(HttpContext.Session.GetInt32("id") != null){
                
                string userQuery = $"SELECT * FROM users WHERE id = '{id}'";
                Dictionary<string, object> user = _dbConnector.Query(userQuery).SingleOrDefault();
                ViewBag.user = user;

                string ideasQuery = $"SELECT COUNT(ideas.user_id) AS ideas FROM ideas JOIN users ON users.id = ideas.user_id WHERE users.id = '{id}'";
                List<Dictionary<string, object>> ideas = _dbConnector.Query(ideasQuery).ToList();
                ViewBag.ideas = ideas;

                string likesQuery = $"SELECT COUNT(likes.user_id) AS likes FROM likes JOIN users ON users.id = likes.user_id WHERE users.id = '{id}';";
                List<Dictionary<string, object>> likes = _dbConnector.Query(ideasQuery).ToList();
                ViewBag.likes = likes;
                
                return View("Profile");
            }
            return RedirectToAction("index", "Users");
        }
    }
}

